package app.circlesearch

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.core.content.FileProvider
import java.io.File

object LensLauncher {

    // Urutan prioritas tujuan pencarian visual
    private val targets = listOf(
        "com.google.android.googlequicksearchbox", // Google app (Lens)
        "com.google.ar.lens"                       // Google Lens standalone
    )

    fun buildIntent(ctx: Context, crop: Bitmap): Intent {
        val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
        val file = File(dir, "crop.png")
        file.outputStream().use { crop.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)

        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        for (pkg in targets) {
            val match = ctx.packageManager
                .queryIntentActivities(Intent(send).setPackage(pkg), 0)
                .firstOrNull()?.activityInfo ?: continue
            return Intent(send).setComponent(ComponentName(match.packageName, match.name))
        }
        // Fallback: user memilih sendiri app pencari gambar
        return Intent.createChooser(send, null).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}
