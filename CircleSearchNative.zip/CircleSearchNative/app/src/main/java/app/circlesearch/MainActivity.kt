package app.circlesearch

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "1. Tekan tombol di bawah, pilih \"Circle Search\" sebagai Digital assistant app.\n" +
                "2. Aktifkan \"Gunakan tangkapan layar\".\n" +
                "3. Long-press Home / tombol navigasi (atau power button) untuk memanggilnya."
        })
        root.addView(Button(this).apply {
            text = "Buka pengaturan asisten"
            setOnClickListener { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Tes sekarang"
            setOnClickListener { startActivity(Intent(this@MainActivity, TriggerActivity::class.java)) }
        })
        setContentView(root)
    }
}
