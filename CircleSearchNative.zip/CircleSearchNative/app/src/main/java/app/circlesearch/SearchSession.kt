package app.circlesearch

import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.view.View
import android.widget.Toast

class SearchSession(private val ctx: Context) : VoiceInteractionSession(ctx) {

    private lateinit var selection: SelectionView

    override fun onCreateContentView(): View {
        selection = SelectionView(ctx) { crop ->
            startAssistantActivity(LensLauncher.buildIntent(ctx, crop))
            hide()
        }
        return selection
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        selection.reset()
    }

    override fun onHandleScreenshot(screenshot: Bitmap?) {
        if (screenshot == null) {
            Toast.makeText(ctx, R.string.no_screenshot, Toast.LENGTH_LONG).show()
            hide()
        } else {
            selection.setScreenshot(screenshot)
        }
    }
}
