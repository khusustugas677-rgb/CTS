package app.circlesearch

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

/** Menampilkan screenshot; user melingkari area dengan jari, hasilnya di-crop. */
class SelectionView(
    context: Context,
    private val onResult: (Bitmap) -> Unit
) : View(context) {

    private var shot: Bitmap? = null
    private val path = Path()
    private val bounds = RectF()
    private val dest = RectF()

    private val dimPaint = Paint().apply { color = 0x99000000.toInt() }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * resources.displayMetrics.scaledDensity
        textAlign = Paint.Align.CENTER
        setShadowLayer(8f, 0f, 2f, Color.BLACK)
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f * resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    fun setScreenshot(bitmap: Bitmap) {
        shot = bitmap
        invalidate()
    }

    fun reset() {
        path.reset()
        shot = null
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        dest.set(0f, 0f, w.toFloat(), h.toFloat())
        strokePaint.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(0xFF4285F4.toInt(), 0xFFEA4335.toInt(), 0xFFFBBC05.toInt(), 0xFF34A853.toInt()),
            null, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = shot ?: return
        canvas.drawBitmap(bmp, null, dest, null)
        if (path.isEmpty) {
            canvas.drawRect(dest, dimPaint)
            canvas.drawText(
                context.getString(R.string.hint),
                width / 2f, height - 96f * resources.displayMetrics.density, hintPaint
            )
        } else {
            canvas.save()
            canvas.clipOutPath(path)          // gelapkan hanya area di luar lingkaran
            canvas.drawRect(dest, dimPaint)
            canvas.restore()
            canvas.drawPath(path, strokePaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (shot == null) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { path.reset(); path.moveTo(e.x, e.y) }
            MotionEvent.ACTION_MOVE -> path.lineTo(e.x, e.y)
            MotionEvent.ACTION_UP -> { path.lineTo(e.x, e.y); finishSelection() }
        }
        invalidate()
        return true
    }

    private fun finishSelection() {
        val bmp = shot ?: return
        path.computeBounds(bounds, true)
        val pad = 16f * resources.displayMetrics.density
        val sx = bmp.width / width.toFloat()
        val sy = bmp.height / height.toFloat()
        val l = ((bounds.left - pad) * sx).toInt().coerceIn(0, bmp.width - 1)
        val t = ((bounds.top - pad) * sy).toInt().coerceIn(0, bmp.height - 1)
        val r = ((bounds.right + pad) * sx).toInt().coerceIn(l + 1, bmp.width)
        val b = ((bounds.bottom + pad) * sy).toInt().coerceIn(t + 1, bmp.height)
        val minSize = 48 * resources.displayMetrics.density
        if ((r - l) < minSize || (b - t) < minSize) {   // dianggap tap, bukan lingkaran
            path.reset()
            return
        }
        onResult(Bitmap.createBitmap(bmp, l, t, r - l, b - t))
    }
}
