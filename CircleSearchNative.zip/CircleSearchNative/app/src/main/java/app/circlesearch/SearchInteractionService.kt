package app.circlesearch

import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession

/**
 * Aktif otomatis saat app dipilih sebagai "Digital assistant app".
 * Sistem memanggilnya lewat long-press Home / tombol navigasi / power button,
 * sama seperti Circle to Search bawaan.
 */
class SearchInteractionService : VoiceInteractionService() {

    override fun onReady() {
        super.onReady()
        instance = this
    }

    override fun onShutdown() {
        super.onShutdown()
        if (instance === this) instance = null
    }

    companion object {
        @Volatile
        var instance: SearchInteractionService? = null

        /** Memunculkan sesi (dipakai tile, shortcut, dan tombol tes). */
        fun trigger(): Boolean {
            val service = instance ?: return false
            service.showSession(
                Bundle(),
                VoiceInteractionSession.SHOW_WITH_ASSIST or VoiceInteractionSession.SHOW_WITH_SCREENSHOT
            )
            return true
        }
    }
}
