package app.circlesearch

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/** Activity transparan: tunggu panel notifikasi tertutup, lalu ambil screenshot bersih. */
class TriggerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = applicationContext
        Handler(Looper.getMainLooper()).postDelayed({
            if (!SearchInteractionService.trigger()) {
                Toast.makeText(app, R.string.not_default, Toast.LENGTH_LONG).show()
            }
        }, 350)
        finish()
    }
}
