package app.circlesearch

import android.content.Intent
import android.speech.RecognitionService

/** Hanya syarat sistem agar app bisa dipilih sebagai asisten; tidak melakukan apa pun. */
class StubRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {}
    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
